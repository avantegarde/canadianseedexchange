<?php

echo 'hamdolah';