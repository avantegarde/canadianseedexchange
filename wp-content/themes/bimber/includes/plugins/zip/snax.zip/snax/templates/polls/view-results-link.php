<div class="snax-poll-toggle-results snax-poll-toggle-results-active">
    <button type="button" class="snax-action snax-action-poll-view-results"><?php echo esc_html_x( 'View results', 'Poll', 'snax' ); ?></button>
    <button type="button" class="snax-action snax-action-poll-hide-results snax-action-hidden snax-poll-question-answered"><?php echo esc_html_x( 'Hide results', 'Poll', 'snax' ); ?></button>
    <button type="button" class="snax-action snax-action-poll-hide-results snax-action-hidden snax-poll-question-not-answered"><?php echo esc_html_x( 'Hide results to vote', 'Poll', 'snax' ); ?></button>
</div>

